﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace AdoDemo
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        //private string presence;

        protected void Page_Load(object sender, EventArgs e)
        {
            string CS = ConfigurationManager.ConnectionStrings["DBCS"].ConnectionString;
            using (SqlConnection con = new SqlConnection(CS))
            {
                string command = "SELECT emp_id ,emp_name ,emp_dept, isPresent FROM Employees_Details";
                SqlCommand cmd = new SqlCommand(command, con);
                con.Open();
                using (SqlDataReader rdr = cmd.ExecuteReader())
                {
                    DataSet ds = new DataSet();
                    ds.Tables.Add("WebForm1");
                    ds.Tables[0].Load(rdr);
                    DataRow dataRow = ds.Tables[0].NewRow();
                    dataRow["emp_id"] = 1;
                    dataRow["emp_name"] = "Hi";
                    dataRow["emp_dept"] = "Hii";
                    dataRow["isPresent"] = "Hiii";
                    ds.Tables[0].Rows.Add(dataRow);

                    GridView2.DataSource = ds;
                    GridView2.DataBind();
                    //-----------------------------
                    ds.Tables.Add("WebForm11");
                    ds.Tables[1].Load(rdr);
                    GridView1.DataSource = ds;
                    GridView1.DataBind();
                    //-----------------------------
                    ds.Tables.Add("WebForm111");
                    ds.Tables[2].Load(rdr);
                    GridView3.DataSource = ds;
                    GridView3.DataBind();
                    //DataTable table = new DataTable();
                    //table.Columns.Add("Employee Id");
                    //table.Columns.Add("Employee Name");
                    //table.Columns.Add("Employee Dept");
                    //table.Columns.Add("IsEmployeePresent");

                    //while (rdr.Read())
                    //{
                    //    DataRow dataRow = table.NewRow();
                    //    int present = Convert.ToInt32(rdr["isPresent"]);

                    //    switch (present)
                    //    {

                    //        case 0:
                    //            presence = "Absent";
                    //            break;
                    //        case 1:
                    //            presence = "Present";
                    //            break;
                    //        case 2:
                    //            presence = "Not updated";
                    //            break;
                    //    }

                    //    dataRow["Employee Id"] = rdr["emp_id"];
                    //    dataRow["Employee Name"] = rdr["emp_name"];
                    //    dataRow["Employee Dept"] = rdr["emp_dept"];
                    //    dataRow["IsEmployeePresent"] = presence;
                    //    table.Rows.Add(dataRow);

                    //    GridView2.DataSource = table;
                    //    GridView2.DataBind();
                }

                }
            }

        protected void btnShow_Click(object Sender, EventArgs e)
        {
            Response.Redirect("WebForm2.aspx");
        }
    }
}