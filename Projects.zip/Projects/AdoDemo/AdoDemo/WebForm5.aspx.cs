﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace AdoDemo
{
    public partial class WebForm5 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack) //If we have a get request for this page
            {
                string CS = ConfigurationManager.ConnectionStrings["DBCS"].ConnectionString;
                SqlConnection con = new SqlConnection(CS);
                string strSelectQuery = "Select * from Employees_Details";
                SqlDataAdapter da = new SqlDataAdapter(strSelectQuery, con);

                DataSet ds = new DataSet(); //untyped Datasets
                da.Fill(ds, "Employees");

                Session["DATASET"] = ds;
                //within the employee table every row is a employee object , so we want to convert every data row in the 
                //employee table into employee object

                GridView1.DataSource = from dataRow in ds.Tables["Employees"].AsEnumerable()
                                       select new Employee
                                       {
                                           Emp_Id = Convert.ToInt32(dataRow["emp_id"]),
                                           Emp_Name = dataRow["emp_name"].ToString(),
                                           Emp_Dept = dataRow["emp_dept"].ToString(),
                                           IsPresent = dataRow["isPresent"].ToString(),
                                           Hours = Convert.ToInt32(dataRow["hours"])
                                       };
                GridView1.DataBind();
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            DataSet ds = (DataSet)Session["DATASET"];

            if (TextBox1.Text == null)
            {

                GridView1.DataSource = from dataRow in ds.Tables["Employees"].AsEnumerable()
                                       select new Employee
                                       {
                                           Emp_Id = Convert.ToInt32(dataRow["emp_id"]),
                                           Emp_Name = dataRow["emp_name"].ToString(),
                                           Emp_Dept = dataRow["emp_dept"].ToString(),
                                           IsPresent = dataRow["isPresent"].ToString(),
                                           Hours = Convert.ToInt32(dataRow["hours"])
                                       };
                GridView1.DataBind();
            }
            else
            {
                GridView1.DataSource = from dataRow in ds.Tables["Employees"].AsEnumerable()
                                       where dataRow["emp_name"].ToString().ToUpper().StartsWith(TextBox1.Text.ToUpper())
                                       select new Employee
                                       {
                                           Emp_Id = Convert.ToInt32(dataRow["emp_id"]),
                                           Emp_Name = dataRow["emp_name"].ToString(),
                                           Emp_Dept = dataRow["emp_dept"].ToString(),
                                           IsPresent = dataRow["isPresent"].ToString(),
                                           Hours = Convert.ToInt32(dataRow["hours"])
                                       };
                GridView1.DataBind();
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("WebForm6.aspx");
        }
    }
}