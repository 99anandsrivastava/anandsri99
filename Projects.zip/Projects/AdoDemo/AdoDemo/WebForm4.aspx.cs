﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace AdoDemo
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        private void GetDataFromDb()
        {
            string CS = ConfigurationManager.ConnectionStrings["DBCS"].ConnectionString;
            SqlConnection con = new SqlConnection(CS);
            string strSelectQuery = "Select * from Employees_Details";
            SqlDataAdapter da = new SqlDataAdapter(strSelectQuery, con);

            DataSet ds = new DataSet();
            da.Fill(ds, "Employees");

            ds.Tables["Employees"].PrimaryKey = new DataColumn[] { ds.Tables["Employees"].Columns["emp_id"] };
            Cache.Insert("DATASET", ds, null, DateTime.Now.AddHours(24), System.Web.Caching.Cache.NoSlidingExpiration);

            gbEmployees.DataSource = ds;
            gbEmployees.DataBind();

            lblMessage.Text = "Data Loaded from Database"; 
        }

        private void GetDataFromCache()
        {
            if(Cache["DATASET"]!=null)
            {
                DataSet ds = (DataSet)Cache["DATASET"];
                gbEmployees.DataSource = ds;
                gbEmployees.DataBind();
            }
        }
        protected void btnGetDataFromDb_Click(object sender, EventArgs e)
        {
            GetDataFromDb();
        }

        protected void gbEmployees_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gbEmployees.EditIndex = e.NewEditIndex; //puts in edit mode . 
            GetDataFromCache();
        }

        protected void gbEmployees_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            if(Cache["DATASET"]!=null)
            {
                DataSet ds = (DataSet)Cache["DATASET"];
                DataRow dr = ds.Tables["Employees"].Rows.Find(e.Keys["emp_id"]);
                dr["emp_name"] = e.NewValues["emp_name"];
                dr["emp_dept"] = e.NewValues["emp_dept"];
                dr["isPresent"] = e.NewValues["isPresent"];
                dr["hours"] = e.NewValues["hours"];

                Cache.Insert("DATASET", ds, null, DateTime.Now.AddHours(24), System.Web.Caching.Cache.NoSlidingExpiration);
                gbEmployees.EditIndex = -1;
                GetDataFromCache();
            }
        }

        protected void gbEmployees_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gbEmployees.EditIndex = -1; //puts in normal mode . 
            GetDataFromCache();
        }

        protected void gbEmployees_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            if (Cache["DATASET"] != null)
            {
                DataSet ds = (DataSet)Cache["DATASET"];
                DataRow dr = ds.Tables["Employees"].Rows.Find(e.Keys["emp_id"]);
                dr.Delete();

                Cache.Insert("DATASET", ds, null, DateTime.Now.AddHours(24), System.Web.Caching.Cache.NoSlidingExpiration);
                
                GetDataFromCache();
            }
        }

        protected void btnUpdateDb_Click(object sender, EventArgs e)
        {
            string CS = ConfigurationManager.ConnectionStrings["DBCS"].ConnectionString;
            SqlConnection con = new SqlConnection(CS);
            string strSelectQuery = "Select * from Employees_Details";
            SqlDataAdapter da = new SqlDataAdapter(strSelectQuery, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);

            DataSet ds = (DataSet)Cache["DATASET"];

            
            da.Update(ds, "Employees");

            lblMessage.Text = "Database Updated";

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            DataSet ds = (DataSet)Cache["DATASET"];
            if(ds.HasChanges())
            {
                ds.RejectChanges();
                Cache.Insert("DATASET", ds, null, DateTime.Now.AddHours(24), System.Web.Caching.Cache.NoSlidingExpiration);
                GetDataFromCache();
                lblMessage.Text = "Changes Undone";
                lblMessage.ForeColor = System.Drawing.Color.Green;

            }
            else
            {
                lblMessage.Text = "No changes to undo";
                lblMessage.ForeColor = System.Drawing.Color.Red;
            }

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("WebForm5.aspx");
        }

        //protected void Button1_Click(object sender, EventArgs e)
        //{
        //    DataSet ds = (DataSet)Cache["DATASET"];
        //    foreach(DataRow dr in ds.Tables["Employees"].Rows)
        //    {
        //        if(dr.RowState == DataRowState.Deleted)
        //        {
        //            Response.Write(dr["emp_id" , DataRowVersion.Original].ToString() + " - " + dr.RowState.ToString() + "<br/>");
        //        }
        //        else
        //        {
        //            Response.Write(dr["emp_id"].ToString() + " - " + dr.RowState.ToString() + "<br/>");
        //        }

        //    }
        //}
    }
}