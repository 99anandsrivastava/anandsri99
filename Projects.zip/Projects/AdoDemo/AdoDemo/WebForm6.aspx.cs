﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AdoDemo
{
    public partial class WebForm6 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                EmployeeDataSetTableAdapters.Employees_DetailsTableAdapter employeeTableAdapter = new EmployeeDataSetTableAdapters.Employees_DetailsTableAdapter();
                EmployeeDataSet.Employees_DetailsDataTable employeeDataTable = new EmployeeDataSet.Employees_DetailsDataTable();
                employeeTableAdapter.Fill(employeeDataTable);

                Session["DATASET"] = employeeDataTable;

                GridView1.DataSource = from employee in employeeDataTable
                                       select new
                                       {
                                           employee.emp_id,
                                           employee.emp_name,
                                           employee.emp_dept,
                                           employee.isPresent,
                                           employee.hours
                                       };
                GridView1.DataBind();
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            EmployeeDataSet.Employees_DetailsDataTable employeeDataTable = (EmployeeDataSet.Employees_DetailsDataTable)Session["DATASET"];
            if(TextBox1.Text == null)
            {
                GridView1.DataSource = from employee in employeeDataTable
                                       select new
                                       {
                                           employee.emp_id,
                                           employee.emp_name,
                                           employee.emp_dept,
                                           employee.isPresent,
                                           employee.hours
                                       };
                GridView1.DataBind();
            }
            else
            {
                GridView1.DataSource = from employee in employeeDataTable
                                       where employee.emp_name.ToUpper().StartsWith(TextBox1.Text.ToUpper())
                                       select new
                                       {
                                           employee.emp_id,
                                           employee.emp_name,
                                           employee.emp_dept,
                                           employee.isPresent,
                                           employee.hours
                                       };
                GridView1.DataBind();
            }
        }
    }
}