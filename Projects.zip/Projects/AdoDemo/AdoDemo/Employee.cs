﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AdoDemo
{
    public class Employee
    {
        public int Emp_Id { get; set; }
        public string Emp_Name { get; set; }
        public string Emp_Dept { get; set; }
        public string IsPresent { get; set; }
        public int Hours { get; set; }

    }
}