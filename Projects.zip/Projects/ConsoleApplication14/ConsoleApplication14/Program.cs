﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace ConsoleApplication14
//{
//    class Program
//    {
//        public static void Main()
//        {

//            string[] ls = Array.ConvertAll(Console.ReadLine().Split(' ').ToArray(), x => x);
//            var t = ls.OrderBy(x2 => x2).GroupBy(x1 => x1);
//            var z1 = t.OrderByDescending(t1 => t1.Count()).FirstOrDefault();
//            Console.WriteLine($"{z1.Count()}\n{z1.Key} \n ");
//            foreach(var y in t)
//            {
//                if(z1.Key!=y.Key)
//                {
//                    Console.WriteLine($"{y.Key}");
//                }
//            }
//            Console.WriteLine("=============================================");
//            //=============================================
//            int[] l1 = new int[6] { 1, 20, -10, 22, 52, 41 };
//            var p1 = l1.Aggregate((i, j) => (i + j));
//            //Dictionary<int, int> dic = new Dictionary<int, int>();
//            //for (int i = 0; i < l1.Length; i++)
//            //{
//            //    int j = 0;
//            //    for (j = i; j < l1.Length; j++)
//            //    {
//            //        if (l1[i] + l1[j] == 42 && i != j)
//            //        {
//            //            dic[l1[i]] = l1[j];
//            //        }

//            //    }
//            //}
//            //foreach (KeyValuePair<int, int> item in dic)
//            //{
//            //    Console.Write($" ( {item.Key}, {item.Value} ) ");
//            //}

//        }


//    }
//}

using System;
using System.Linq;
using System.Collections.Generic;

public static class MaxPositive
{
    public static int findMaximumPositiveIndex(this int[] arr)
    {
        int min = arr[0], max = arr[0], minIndex = 0, maxIndex = 0;
        int maximumIndex = 0;
        for (int i = 0; i < arr.Length; i++)
        {
            min = arr[i];
            minIndex = i;
            bool isMaxPresent = false;
            for (int j = i; j < arr.Length; j++)
            {
                if (arr[j] > min)
                {
                    max = arr[j];
                    maxIndex = j;
                    isMaxPresent = true;
                }
            }
            if (maximumIndex < ((maxIndex - minIndex) + 1))
            {
                maximumIndex = (maxIndex - minIndex) + 1;
            }
        }
        return maximumIndex;
    }
}

public class Test
{
    public static void Main(string[] arr)
    {
        int nT = Convert.ToInt32(Console.ReadLine());
        List<int> output = new List<int>();


        for (int i = 0; i < nT; i++)
        {
            int zz = Convert.ToInt32(Console.ReadLine());
            output.Add(Array.ConvertAll(Console.ReadLine().Split(' ').ToArray(), u => Convert.ToInt32(u)).findMaximumPositiveIndex());
        }
        output.ToList().ForEach(x => Console.WriteLine(x));
        
    }
}
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ConsoleApplication13
{
    public class Program
    {
        public static void Main(string[] args)
        {




            //public class bc
            //{
            //    public virtual void Print() {
            //        Console.WriteLine("B");
            //    }
            //}
            //public class dc : bc
            //{
            //    public virtual void Print()
            //    {
            //        Console.WriteLine("D");
            //    }
            //}

            ///*public class ec : dc { public override void Print() { Console.WriteLine("E"); } }*///cannot override inherited member 'dc.Print()' 
            //                                                                                     //because it is not marked virtual, abstract, or override ConsoleApplication13 

            //class Test
            //{
            //    public static void Main()
            //    {
            //        bc b = new bc();
            //        b.Print();//B
            //        dc d = new dc();
            //        d.Print();//D

            //        bc bd = new dc();
            //        bd.Print();//B

            //    }
            //}
        }
    }
}




//class Program
//{
//    public static void Main()
//    {
//        bc b = new bc();
//        b.Print();

//        bc c = new dc();
//        c.Print();

//        dc d = new dc();
//        d.Print();

//        //dc e = new bc();
//        //e.Print();

//        //Console.WriteLine(string.Join(" ", Console.ReadLine().Split(' ').ToArray().OrderBy(x => x.Length).ThenBy(x=>x).ToArray()));



//        //string test = "We are not American nor he is Indian";
//        //List<string> testList = new List<string>();
//        //string[] words = test.Split(' ');
//        //foreach(string word in words)
//        //{
//        //    testList.Add(word);
//        //}

//        //testList = testList.OrderBy(s => s.Length).ToList();

//        //foreach(string s in testList)
//        //{
//        //    Console.Write(s + " ");
//        //}
//    }
//}

//public class bc
//{
//    public virtual void Print()
//    {
//        Console.WriteLine("BCPM");
//    }

//}
//public class dc : bc
//{
//    public new void Print()
//    {
//        Console.WriteLine("DCPM");
//    }
//}




//static void Main(string[] args)
//{
//    Dictionary<char, int> dict = new Dictionary<char, int>();
//    foreach (char x in Console.ReadLine())
//    {
//        if (dict.ContainsKey(x))
//        {
//            dict[x] += 1;
//            //a 2
//            //b 2
//        }
//        else
//        {
//            dict.Add(x, 1);
//            //a 1
//            //b 1
//        }
//    }
//    foreach (KeyValuePair<char, int> item in dict)
//    {

//        Console.WriteLine(item.Key);
//    }

//Console.WriteLine(Console.ReadLine().Distinct().ToArray());
//string name = "anandsrivastava";
//            while (name.Length > 0)
//            {
//                Console.Write("Occurence of {0} is " , name[0]);
//                int count = 0;
//                for (int j = 0; j<name.Length; j++)
//                {
//                    if (name[0] == name[j])
//                    {
//                        count++;
//                    }
//                }
//                Console.WriteLine(count);
//                name = name.Replace(name[0].ToString(), string.Empty);
//            }



//            int count = 0;
//            for(int i = 0; i <=name.Length;i++)
//            {
//                char toTry = name[i];
//                Console.Write("Occurence of {0} is", toTry);

//                for(int j = i+1; j<=name.Length;j++)
//                {
//                    if (j >= name.Length)
//                    { }
//                    else
//                    {
//                        if (name[j] == toTry)
//                        {
//                            count++;
//                        }
//                    }

//                }
//                Console.WriteLine(count);
//            }

//        }  
//    }
//}
