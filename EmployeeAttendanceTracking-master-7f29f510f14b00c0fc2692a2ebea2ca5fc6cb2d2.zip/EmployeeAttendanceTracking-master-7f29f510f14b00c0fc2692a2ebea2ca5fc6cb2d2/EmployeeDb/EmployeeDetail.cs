namespace EmployeeDb
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class EmployeeDetail
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int emp_id { get; set; }

        [Required]
        [StringLength(50)]
        public string emp_name { get; set; }

        [Required]
        [StringLength(50)]
        public string emp_dept { get; set; }

        [StringLength(1)]
        public string isPresent { get; set; }

        public int? Hours { get; set; }
    }
}
