﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeDb
{
   public class Employee_DetailsDBC
    {
        public List<Employees_Details> GetEmployeeDetails()
        {
            using (practiceEntities entities = new practiceEntities())
            {
                var empDetailsList = entities.Employees_Details.ToList();
                return empDetailsList;

                
            }
        }

        public bool presenceUpdate( int id , string presence , int? hours = 0)
        {
            using (practiceEntities entities = new practiceEntities())
            {
                var empDetail = entities.Employees_Details.FirstOrDefault(c => c.emp_id == id);
                if (empDetail == null)
                    return false; 
                else
                {
                    empDetail.isPresent = presence;
                    empDetail.hours = hours;
                    entities.Entry(empDetail).State = System.Data.Entity.EntityState.Modified;
                    entities.SaveChanges();
                    return true;
                }
                
            }
        }

        public bool setToDefault()
        {
            using (practiceEntities entities = new practiceEntities())
            {
                IEnumerable<Employees_Details> employeeList =
                    entities.Employees_Details.ToList();

                if (employeeList == null)
                {
                    return false;
                }
                else
                {

                    foreach (Employees_Details emp in employeeList)
                    {
                        emp.isPresent = "2";
                        emp.hours = 10;
                        entities.Entry(emp).State = System.Data.Entity.EntityState.Modified;
                        
                    }
                    entities.SaveChanges();
                    return true;

                }
            }
        }
    }
}
