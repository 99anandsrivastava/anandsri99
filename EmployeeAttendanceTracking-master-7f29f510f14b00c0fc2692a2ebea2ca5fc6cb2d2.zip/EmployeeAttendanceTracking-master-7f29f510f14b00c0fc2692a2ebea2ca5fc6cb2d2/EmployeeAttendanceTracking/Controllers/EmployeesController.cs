﻿using EmployeeDb;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Runtime.Serialization;
using System.Web.Http;


namespace EmployeeAttendaceTracking.Controllers
{
    //[Authorize]
    public class EmployeesController : ApiController
    {
        public HttpResponseMessage Get()
        {
            Employee_DetailsDBC edbc = new Employee_DetailsDBC();
            var listOfEmployees = edbc.GetEmployeeDetails();
            var message = Request.CreateResponse(HttpStatusCode.OK, listOfEmployees);
            return message;

        }

        public HttpResponseMessage Put(int Mid, string presence, int? hours = 0)
        {
            Employee_DetailsDBC edbc = new Employee_DetailsDBC();
            bool result = edbc.presenceUpdate(Mid, presence, hours);
            if (!result)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Bad Request");
            }
            else
            {

            }
            var message = Request.CreateResponse(HttpStatusCode.OK, result);
            return message;
        }

        public HttpResponseMessage Put()
        {
            Employee_DetailsDBC edbc = new Employee_DetailsDBC();
            bool res = edbc.setToDefault();
            if (!res)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Bad Request");
            }
            else
            {

            }
            var msg = Request.CreateResponse(HttpStatusCode.OK, res);
            return msg;
        }

    }  
}
