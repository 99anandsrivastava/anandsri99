import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { EmployeeComponent } from './Employees/employees-list.component';
import { AppComponent } from './app.component';
import {EmployeeService} from './Employees/employees-list.service';
import { LoginComponent} from './Login/login-component';
import {FormsModule} from '@angular/forms';
import {LoginService} from './Login/login-service';
import { HttpModule } from '@angular/http';
import { RegisterComponent } from './Register/register-component';
import { RegisterService } from './Register/register.service';
import { RouterModule } from '@angular/router';
import {WelcomePageComponent} from './WelcomePage/welcomePage.component';
import {AttendanceModule} from './material_design/material.module';
import {ReactiveFormsModule } from '@angular/forms';
import {AuthGuard} from './Login/auth-guard.service';
import {MessageComponent} from './message/message.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    WelcomePageComponent,
    MessageComponent,
    EmployeeComponent
  ],

  entryComponents: [MessageComponent],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
     HttpClientModule,
     RouterModule.forRoot([
       {
         path: 'employee',
         component:EmployeeComponent,
          canActivate : [AuthGuard]
       },
       {
         path: 'register',
         component :RegisterComponent
        
       },
       {
         path: 'login',
         component: LoginComponent
       },
       {
        path: '',
        component: WelcomePageComponent
      }
     ]),
     AttendanceModule,
     HttpModule
  ],
  providers: [EmployeeService , LoginService , RegisterService , AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
