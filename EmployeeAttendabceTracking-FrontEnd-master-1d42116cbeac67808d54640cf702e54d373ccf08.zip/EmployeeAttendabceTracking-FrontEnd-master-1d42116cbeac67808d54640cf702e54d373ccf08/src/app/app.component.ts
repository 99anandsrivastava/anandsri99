import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})


export class AppComponent {
  title = 'app';
  isAuthenticated: boolean;
constructor(private router : Router)
{

}

isLoggedIn()
{
  if(sessionStorage.getItem('access_token')!=null){
    return true;
}else{
  return false;
}
  
}


logout() {
    sessionStorage.clear();
    this.router.navigate[('')];
  }
}

