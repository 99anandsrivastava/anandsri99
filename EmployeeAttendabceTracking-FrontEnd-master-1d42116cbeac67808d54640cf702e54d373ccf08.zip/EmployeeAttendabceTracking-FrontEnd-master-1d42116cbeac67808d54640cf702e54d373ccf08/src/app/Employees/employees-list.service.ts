import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { Headers , Http} from '@angular/http';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/map';
import { environment } from '../../environments/environment';
@Injectable()
export class EmployeeService{

    private EmployeeURL = environment.apiUrl + "api/employees";
    private UpdateURL = environment.apiUrl + "api/employees?Mid=";
    
    

    constructor(private http : Http)
    {

    }
    
    getEmployees() : Observable<any[]>{
        let headers = new Headers({'Authorization': 'Bearer '+ sessionStorage.getItem('access_token')});

        return this.http.get(this.EmployeeURL, {headers : headers})
                .map(res => res.json())
                .do(data =>  console.log("Employees: " + JSON.stringify(data)));
      //  return this.employeDetails;

    }
    updatePresence(Id : number , Presence : string):Observable<any>
    {
        return this.http.put(this.UpdateURL + Id +"&presence=" +Presence , {}).
        do(data=>console.log("The URL is"+JSON.stringify(this.UpdateURL + Id +"&presence=" +Presence)));
    }

    updateHoursEmployee(Id : number , Presence : string , Hours : number):Observable<any>
    {
        return this.http.put(this.UpdateURL + Id +"&presence=" +Presence +"&hours=" +Hours , {}).
        do(data=>console.log("The URL is"+JSON.stringify(this.UpdateURL + Id +"&presence=" +Presence+"&hours=" +Hours)));
    }
}