import { Component , OnInit } from '@angular/core';
import { EmployeeService } from './employees-list.service';
import 'rxjs/add/operator/do';
import {platformBrowserDynamic} from '@angular/platform-browser-dynamic'; 
import {BrowserModule} from '@angular/platform-browser'; 
import {FormControl, Validators} from '@angular/forms';
@Component({
    selector : 'app-employee', 
    templateUrl : 'employees-list.component.html'
})

export class EmployeeComponent implements OnInit {
employees :any[] = [];
Username : string;
showButtons : number = -1;
showHour : number = -1;
    constructor(private employeeService : EmployeeService)
    {
        this.Username = sessionStorage.getItem('username');
    

    }
    HoursControl : any;

    ngOnInit()
    {
        this.employeeService.getEmployees().subscribe(employeeGet => this.employees = employeeGet);
        //console.log(this.employees);
        this.HoursControl = new FormControl('', [Validators.required]);
    }
    showOptions(value: number)
    {
        this.showButtons = value;
    }

    showHours(val : number)
    {
        this.showHour = val;
    }

    populate()
    {
        this.employeeService.getEmployees().subscribe(employeeGet => this.employees = employeeGet);
    }

    update( Id : number , Presence : string)
    {
        this.employeeService.updatePresence(Id,Presence).subscribe
        (response => {
            console.log(response);
            this.populate();
        });
        
    }
    updateHours( Id : number , Presence : string , Hours : number)
    {
        this.employeeService.updateHoursEmployee(Id,Presence,Hours).subscribe
        (response => {
            console.log(response);
            this.populate();
        });
        
    }
    
}