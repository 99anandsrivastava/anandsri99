import { Injectable } from '@angular/core';
import { Headers , Http} from '@angular/http';
import {Observable} from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { environment } from '../../environments/environment';
@Injectable()
export class RegisterService {

constructor(private http : Http)
{   
}
private headers = new Headers({'Content-type': 'application/json' });

registerUser(email , password , confirmPassword)
{
    let body = {
        "Email" : email , 
        "Password": password , 
        "ConfirmPassword" : confirmPassword
    };
    this.http.post( environment.apiUrl +   "api/account/register" ,body,{headers: this.headers}).
        map(result => 
        {
            if(result.status == 200)
            {
                alert('Registration Succesful');
            }
        }).catch((error: any) => {
            if(error.status == 400)
            {
                alert('Email already exists');
                return Observable.throw(new Error(error.status));
            }
        }).subscribe();
        

}


}