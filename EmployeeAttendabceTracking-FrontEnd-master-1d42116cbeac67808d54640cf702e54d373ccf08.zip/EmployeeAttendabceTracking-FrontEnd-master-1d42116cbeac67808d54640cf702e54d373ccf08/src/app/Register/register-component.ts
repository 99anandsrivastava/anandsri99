import { Component , OnInit } from '@angular/core';
import {FormControl, Validators} from '@angular/forms';
import { RegisterService} from './register.service';
const EMAIL_REGEX = /^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
const PASSWORD_REGEX = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&]{8,}/;
@Component({
    selector : 'app-register', 
    templateUrl : 'register-component.html',
    styleUrls:["../Login/login-component.css"]
})

export class RegisterComponent implements OnInit{
    email: any;
    password: any;
    confirmPassword: any;


    constructor(private registerService : RegisterService)
    {

    }
    emailFormControl : any;
    PasswordFormControl :any;
    ConfirmPasswordFormControl : any;
    ngOnInit()   
    {
    this.emailFormControl = new FormControl('', [Validators.required,Validators.pattern(EMAIL_REGEX)]);

    this.PasswordFormControl = new FormControl('', [Validators.required,Validators.pattern(PASSWORD_REGEX)]);
    this.ConfirmPasswordFormControl = new FormControl('', [Validators.required,Validators.pattern(PASSWORD_REGEX)]);
    }

    register()
    {
    this.registerService.registerUser(this.emailFormControl.value ,this.PasswordFormControl.value , this.ConfirmPasswordFormControl.value);
    }
}