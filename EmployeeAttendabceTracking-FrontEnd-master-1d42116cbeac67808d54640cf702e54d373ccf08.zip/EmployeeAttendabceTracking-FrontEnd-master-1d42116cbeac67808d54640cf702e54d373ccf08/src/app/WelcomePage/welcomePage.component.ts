import { Component, AfterViewInit ,  OnInit , AfterContentInit , Renderer , ViewChild ,  ComponentFactoryResolver , ViewContainerRef  } from '@angular/core';
import {MessageComponent } from '../message/message.component';

@Component({
  selector: 'app-welcomePageComponent',
  templateUrl : 'welcomePage.component.html',
  styleUrls:["welcomePage.component.css"]
})
export class WelcomePageComponent implements OnInit , AfterContentInit {

@ViewChild('container' , { read : ViewContainerRef}) container;
  constructor(private resolver : ComponentFactoryResolver) {
    
   }

  ngOnInit() {
  }

  ngAfterContentInit()
  {
    const MessageFactory = this.resolver.resolveComponentFactory(MessageComponent);
    this.container.createComponent(MessageFactory);
  }

}
