import { Injectable } from '@angular/core';
import { Headers , Http} from '@angular/http';
import 'rxjs/add/operator/map';
import { Router } from "@angular/router";
import {Observable} from 'rxjs/Rx';
import { environment } from '../../environments/environment';
@Injectable()
export class LoginService {

    
    constructor(private http : Http , private _route : Router)
    {
    }
    private headers = new Headers({'Content-type': 'application/x-www-form-urlencoded' });

    getAccessToken(username , password)
    {
        sessionStorage.clear();
        let body = "grant_type=password&username=" + username + "&password=" +password;
        this.http.post( environment.apiUrl + "token",body,{headers: this.headers})
         .map(res => res.json()).catch((error: any) => { 
            if(error.status == 400)
            {
        
                alert('The user name or password is incorrect');
                return Observable.throw(new Error(error.status));
            }
        }).subscribe(
             data => {
                 sessionStorage.setItem('access_token' , data.access_token);
                 sessionStorage.setItem('username' , data.userName);

                 this._route.navigate(['employee']);
             }
         )
    }

     
  
}





