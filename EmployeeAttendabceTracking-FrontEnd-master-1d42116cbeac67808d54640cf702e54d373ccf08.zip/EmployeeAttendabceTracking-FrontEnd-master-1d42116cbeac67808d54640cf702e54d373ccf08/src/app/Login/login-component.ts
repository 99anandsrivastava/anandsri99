import { Component , OnInit } from '@angular/core';
import { LoginService } from './login-service';
import {FormControl, Validators} from '@angular/forms';
const EMAIL_REGEX = /^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
@Component({
    selector : 'app-login', 
    templateUrl : 'login-component.html',
    styleUrls: ['login-component.css']
})

export class LoginComponent implements OnInit {

username: any;
password: any;

    constructor(private loginService : LoginService)
    {

    }

emailFormControl : any;
PasswordFormControl :any;
    ngOnInit()
    {
        this.emailFormControl = new FormControl('', [
    Validators.required,
    Validators.pattern(EMAIL_REGEX)]);
    this.PasswordFormControl = new FormControl('', [Validators.required,Validators.pattern(EMAIL_REGEX)]);
    }

    login()
    {
        this.loginService.getAccessToken(this.emailFormControl.value, this.PasswordFormControl.value);
    }


}