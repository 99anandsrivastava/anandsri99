import { Component, OnInit } from '@angular/core';
import{Router} from '@angular/router';


@Component({
  selector: 'app-advertisement',
  templateUrl: './advertisement.component.html'
})
export class AdvertisementComponent implements OnInit {

  constructor(private _router :Router) {
    
   }
   

  ngOnInit() {
  }

  goToSearch(){
    this._router.navigate(['search']);
  }

}
