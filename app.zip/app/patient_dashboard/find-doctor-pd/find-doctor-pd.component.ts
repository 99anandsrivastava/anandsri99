import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-find-doctor-pd',
  templateUrl: './find-doctor-pd.component.html',
  styleUrls: ['./find-doctor-pd.component.css']
})
export class FindDoctorPdComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }

  goToSearch(){
    this.router.navigate(['search']);
  }
}
