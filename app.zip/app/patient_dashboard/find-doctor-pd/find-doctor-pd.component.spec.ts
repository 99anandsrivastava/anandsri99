import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FindDoctorPdComponent } from './find-doctor-pd.component';

describe('FindDoctorPdComponent', () => {
  let component: FindDoctorPdComponent;
  let fixture: ComponentFixture<FindDoctorPdComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FindDoctorPdComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FindDoctorPdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
