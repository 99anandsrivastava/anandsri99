
import { Injectable } from '@angular/core';
import { Observable } from "rxjs/Observable";
import { Http } from "@angular/http";
import { environment } from '../../../environments/environment';

@Injectable()
export class GetPatientAppointmentDetails{

    private GetAppointmentBaseURL= environment.apiUrl + "/api/Patients/?email=";
    private GetPendingURL = environment.apiUrl + "/api/PatientPending/?email=";
    constructor(private _http:Http){

    }

    GetPatientAppointments(emailId:string):Observable<Response>{
        return this._http.get(this.GetAppointmentBaseURL+emailId).map((res) => res.json());
    
    }

    getPending(){
        return this._http.get(this.GetPendingURL + localStorage.getItem('username')).map(res => res.json());
    }
}