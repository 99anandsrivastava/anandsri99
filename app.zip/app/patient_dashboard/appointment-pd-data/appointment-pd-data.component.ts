import { GetPatientAppointmentDetails } from './../patient-dashboard/patient-dashboard.service';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appointment-pd-data',
  templateUrl: './appointment-pd-data.component.html',
  styleUrls: ['./appointment-pd-data.component.css']
})
export class AppointmentPdDataComponent implements OnInit {
  patient: any;

  appointmentsI: any[];
  currentDate = new Date();
  
  upcoming: any[];
  pending: any[];
  history: any[];

  initFilters(){
    console.log('Patient: ', this.patient);
    this.upcoming = this.patient.appointments.filter( x => x.isApproved == true && new Date(x.startTime) > this.currentDate).sort( (a,b)=> new Date(a.startTime).getTime() - new Date(b.startTime).getTime() );
    
    this.history = this.patient.appointments.filter( x => new Date(x.startTime) < this.currentDate).sort( (a,b)=> new Date(a.startTime).getTime() - new Date(b.startTime).getTime() );
  }
  

  

  constructor(private router: Router, private service: GetPatientAppointmentDetails) { }

  returnToDashboard(){
    this.router.navigate(["patient"]);
  }
  ngOnInit() {
    let user = localStorage.getItem('username');
    this.service.GetPatientAppointments(user)
    .subscribe(res => {
        this.patient = res;
        this.initFilters();
      this.service.getPending().subscribe(data => {
        this.pending = data;
      });
    }, err=> console.log(err));
      
  }

}
