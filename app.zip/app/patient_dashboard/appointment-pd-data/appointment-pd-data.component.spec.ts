import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AppointmentPdDataComponent } from './appointment-pd-data.component';

describe('AppointmentPdDataComponent', () => {
  let component: AppointmentPdDataComponent;
  let fixture: ComponentFixture<AppointmentPdDataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppointmentPdDataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppointmentPdDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
