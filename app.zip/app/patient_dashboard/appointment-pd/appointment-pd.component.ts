import { Router } from '@angular/router';
import { MatDialog } from '@angular/material';
import { Component, OnInit, ViewChild } from '@angular/core';
import { GetPatientAppointmentDetails } from "../patient-dashboard/patient-dashboard.service";
import { Observable } from "rxjs/Observable";

@Component({
  selector: 'app-appointment-pd',
  templateUrl: './appointment-pd.component.html',
  styleUrls: ['./appointment-pd.component.css']
})
export class AppointmentPdComponent implements OnInit {
  patient: any;

  doctorName: any = "No Upcoming Appointment";
  pendingCount: number;
  nextAppointment: any;
   currentDate = new Date();






  constructor(private routers: Router, private service: GetPatientAppointmentDetails) {
  }

  showAppointmentData() {
    this.routers.navigate(['patient/appointments']);
  }

  ngOnInit() {
    let user = localStorage.getItem('username');
    this.service.GetPatientAppointments(user)
      .subscribe(res => {
        this.patient = res;
        if(this.patient.appointments == null){
          this.pendingCount = 0;
        } 
        else{
        this.nextAppointment = this.patient.appointments.filter(x => x.isApproved == true && new Date(x.startTime).getTime() > this.currentDate.getTime()).sort((a, b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime())[0];
        if(this.nextAppointment){
          this.doctorName = this.nextAppointment.doctorName; 
        }
        this.service.getPending().subscribe(data => {
          this.pendingCount = data.length;
        });
        }
      }, err => console.log(err));
  }

}
