import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AppointmentPdComponent } from './appointment-pd.component';

describe('AppointmentPdComponent', () => {
  let component: AppointmentPdComponent;
  let fixture: ComponentFixture<AppointmentPdComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppointmentPdComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppointmentPdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
