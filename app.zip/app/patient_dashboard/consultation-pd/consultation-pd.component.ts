import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-consultation-pd',
  templateUrl: './consultation-pd.component.html',
  styleUrls: ['./consultation-pd.component.css']
})
export class ConsultationPdComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
