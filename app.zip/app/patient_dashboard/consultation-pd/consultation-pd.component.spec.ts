import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsultationPdComponent } from './consultation-pd.component';

describe('ConsultationPdComponent', () => {
  let component: ConsultationPdComponent;
  let fixture: ComponentFixture<ConsultationPdComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConsultationPdComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsultationPdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
