import { Component, OnInit } from '@angular/core';
import { DoctorProfileService } from '../doctor-profile/doctor-profile.service';
import { doctor } from '../doctor-profile/doctor-profile';

@Component({
  selector: 'app-doctor-profile',
  templateUrl: './doctor-profile.component.html',
  styleUrls: ['./doctor-profile.component.css']
})
export class DoctorProfileComponent implements OnInit {
  Name: string;
  Email: string = "sarthak@gmail.com";
  speciality: any;
  experience: any;
  bio: any;
  picture: any;
  licensenumber: any;

  doctor : doctor;
  info: any;

  constructor(private dp: DoctorProfileService) { }

  ngOnInit() {
    this.info = this.dp.GetProfile(this.Email).subscribe((res) => {
      console.log(res);
      this.Name = this.info.Name;
      this.Email = this.info.Email;
      this.speciality = this.info.speciality;
      this.picture = this.info.picture;
    });
  }

  

}
