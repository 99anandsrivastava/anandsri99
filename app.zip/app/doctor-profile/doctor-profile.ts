export class doctor
{
    Name : string;
    speciality: any;
    experience: any;
    bio: any;
    picture: any;
    licensenumber: any;
}