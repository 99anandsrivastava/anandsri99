import { Injectable } from '@angular/core';
import {Http, Response} from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { doctor } from '../doctor-profile/doctor-profile';

@Injectable()
export class DoctorProfileService {

  private url = 'http://localhost:56308/api/DoctorProfile?';
  constructor(private http: Http) { }

  // tslint:disable-next-line:one-line
  GetProfile(email: string) : Observable<any>
  {
    return this.http.get(this.url + 'email=' + email ).map((res:Response) =>  <any>res.json());
  }

}
