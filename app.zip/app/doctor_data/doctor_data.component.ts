import { Component , OnInit} from '@angular/core';
import{ DoctorDataService } from './doctor_data.service';
import{ Router } from '@angular/router';
@Component({
    selector: 'app-doctor-data',
    templateUrl: 'doctor_data.component.html'
})

export class DoctorDataComponent implements OnInit{
doctors: any[];
    constructor( private doctorService : DoctorDataService , private rout : Router)
    {

    }

backToDash()
{
    this.rout.navigate(['./admin']);
}
    ngOnInit()
    {
        this.doctorService.GetData().subscribe
        (doctorGet => this.doctors = doctorGet);
    }
}