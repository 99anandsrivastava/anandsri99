 import { Component, ViewContainerRef, OnInit} from '@angular/core';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { SignupPatientComponent } from './signup-patient/signup-patient.component';
import { SignupDoctorComponent } from './signup-doctor/signup-doctor.component';
import { IdentityService } from './login-front-end/login-service/identity.service'
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'WeHealU';
  d: Date = new Date();
  current_hour: number;
  constructor(public toastr: ToastsManager, vcr: ViewContainerRef, private route: Router) {
    this.toastr.setRootViewContainerRef(vcr);
 }

  ngOnInit() {
    this.current_hour =  this.d.getHours();
    if (this.current_hour > 0 && this.current_hour < 6) {
      this.toastr.info('Hope you had a good day', 'Good Night');
    } else if (this.current_hour >= 6 && this.current_hour < 12) {
      this.toastr.info('Have a nice day', 'Good Morning');
    } else if (this.current_hour >= 12 && this.current_hour < 17) {
      this.toastr.info('Have a nice day', 'Good Afternoon');
    } else if (this.current_hour >= 17 && this.current_hour < 21) {
      this.toastr.info('Have a nice day', 'Good Evening');
    } else {
      this.toastr.info('Hope you had a nice day', 'Good Night');
    }
  }
  }

