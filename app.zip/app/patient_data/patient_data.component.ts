import { Component , OnInit} from '@angular/core';
import{ PatientDataService } from './patient_data.service';
import{ Router } from '@angular/router';

@Component({
    selector: 'app-patient-data',
    templateUrl: 'patient_data.component.html'
})

export class PatientDataComponent implements OnInit{
patients: any[];

    constructor( private patientService : PatientDataService , private rout : Router)
    {

    }
 backToDash()
 {
    this.rout.navigate(['./admin']);
 }
    ngOnInit()
    {
        this.patientService.GetData().subscribe
        (patientGet => {this.patients = patientGet;});
    }
}