import {Injectable} from '@angular/core';
import { Http} from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/map';
import { environment } from '../../environments/environment';

@Injectable()
export class PatientDataService{
 private GetPatientDataUrl = environment.apiUrl + "/api/PatientData";

 constructor(private _httpclient : Http)
 {

 }

 GetData():Observable<any[]>
    {
        return this._httpclient.get(this.GetPatientDataUrl)
        .map(res=>res.json()).do(data => console.log(JSON.stringify(data)));
    }
}