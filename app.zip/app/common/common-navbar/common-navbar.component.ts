import { Component, OnInit, ViewContainerRef, OnChanges } from '@angular/core';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { Router } from '@angular/router';
import { IdentityService } from '../../login-front-end/login-service/identity.service';

@Component({
  selector: 'app-common-navbar',
  templateUrl: './common-navbar.component.html',
  styleUrls: ['./common-navbar.component.css']
})
export class CommonNavbarComponent implements OnInit, OnChanges {
  isAuthenticated: boolean;
  role: string;
  constructor(public toastr: ToastsManager, vcr: ViewContainerRef, private service: IdentityService , private rout : Router) {
    this.toastr.setRootViewContainerRef(vcr);
     if (service.isLoggedIn()) {
       this.isAuthenticated = true;
       this.role = localStorage.getItem('role');
     } else {
       this.isAuthenticated = false;
     }
 }
   ngOnInit() {
  }
  ngOnChanges() {
  }

  welcome()
  {
    this.rout.navigate(['']);
  }
  logout() {
    this.isAuthenticated = false;
    return this.service.logout();
   }
}
