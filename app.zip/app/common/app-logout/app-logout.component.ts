import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app-logout',
  templateUrl: './app-logout.component.html',
  styleUrls: ['./app-logout.component.css']
})
export class AppLogoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
