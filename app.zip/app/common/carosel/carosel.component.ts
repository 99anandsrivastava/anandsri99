import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Rx';

@Component({
  selector: 'app-carosel',
  templateUrl: './carosel.component.html',
  styleUrls: ['./carosel.component.css']
})
export class CaroselComponent implements OnInit {
  isActive1: boolean;
  isActive2: boolean;
  isActive3: boolean;
  carouselItem: number = 0;
  currentItem: number = 0;
  lastItem: number;
  constructor() {
    this.lastItem = 4;
    let timer = Observable.timer(2000, 7000);
    timer.subscribe(t => this.setCarousel());
  }

  setCarousel() {
    if (this.currentItem >= this.lastItem - 1) {
      this.currentItem = this.carouselItem;
    } else {
      this.currentItem++;
    }
  }

  display(place: number ) {
    this.currentItem = place;
  }
  ngOnInit() {
  }

}
