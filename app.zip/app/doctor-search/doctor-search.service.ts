import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/do';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';

import { environment } from '../../environments/environment';

@Injectable()
export class DoctorSearchService {

  private searchURL = environment.apiUrl + "/api/DoctorSearch";

  constructor(private http: Http, private toaster: ToastsManager) { }

  getAllDoctors() {
    return this.http.get(this.searchURL)
      .map(res => res.json())
      .catch((error: any) => {
        if(error.status == 400) {
          return Observable.throw(new Error(error.status));
        }
        else{
            this.toaster.error("Error in Connecting to server");
        }
      });
  }

  getDoctorLocation(){
    return this.http.get(this.searchURL + "?param=getLocation")
      .map(res => res.json())
      .catch((error: any) => {
        if(error.status == 400) {
          return Observable.throw(new Error(error.status));
        }
        else{
            this.toaster.error("Error in Connecting to server");
        }
      });
  }

}
