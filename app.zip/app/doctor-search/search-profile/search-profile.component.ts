import { Component, OnInit, Input } from '@angular/core';

import { Router } from '@angular/router';

@Component({
  selector: 'app-search-profile',
  templateUrl: './search-profile.component.html',
  styleUrls: ['./search-profile.component.css']
})
export class SearchProfileComponent implements OnInit {

  @Input() Name : any;
  @Input() Experience: any;
  @Input() Speciality: any;
  @Input() Rating: any;
  @Input() City: any;
  @Input() State: any;
  @Input() email: any;

  constructor(private router: Router) { }

  ngOnInit() {
  }

  requestDoctor(){
    localStorage.setItem('doctorEmail',this.email);
    this.router.navigate(['doctorBooking']);
    console.log(this.Name);
  }
  

}
