import { TestBed, inject } from '@angular/core/testing';

import { DoctorSearchService } from './doctor-search.service';

describe('DoctorSearchService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DoctorSearchService]
    });
  });

  it('should be created', inject([DoctorSearchService], (service: DoctorSearchService) => {
    expect(service).toBeTruthy();
  }));
});
