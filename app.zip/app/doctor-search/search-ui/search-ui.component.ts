import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';

import { DoctorSearchService } from '../doctor-search.service';
import { SignUpDoctorService } from '../../signup-doctor/signupDoc-service';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-search-ui',
  templateUrl: './search-ui.component.html',
  styleUrls: ['./search-ui.component.css']
})
export class SearchUiComponent implements OnInit {

  doctors: any[];
  filterDoctors: any[];
  selectedExperience: any = 0;
  isExperience: boolean = false;
  anyData: boolean = true;
  selectedRating: any = 0;
  isRating: boolean = false;
  specialities: any[];
  specialityValue: any;
  isSpecial: boolean = false;
  SpecialityFormControl: any;
  LocationFormControl: any;
  isLocate: boolean = false;
  locateValue: any;
  cities: any[];

  constructor(private doctorSearchService: DoctorSearchService, private _SignUpDoctorService : SignUpDoctorService) { }

  ngOnInit() {
    this.LocationFormControl = new FormControl();
    this.SpecialityFormControl = new FormControl();
    this.getDoctors();
    this._SignUpDoctorService.doctorSpeciality( environment.apiUrl + '/api/DoctorSpecialities').subscribe(data => {
      this.specialities = data;
      console.log(data);
    });
    this.doctorSearchService.getDoctorLocation().subscribe(data => {
      this.cities = data});
  }

  getDoctors() {
    this.doctorSearchService.getAllDoctors().subscribe(result => {
      this.doctors = result;
      if (this.isExperience || this.isRating) {
        this.doctors = this.doctors.filter(d => d.Experience >= parseInt(this.selectedExperience) && d.AvgRating >= parseInt(this.selectedRating));
        if(this.doctors.length == 0 && this.isExperience){
          this.anyData = false;
        }
        else{
          this.anyData = true;
        }
      }
      if (this.isSpecial && !this.isLocate) {
        this.doctors = this.doctors.filter(d => d.Experience >= parseInt(this.selectedExperience) && d.AvgRating >= parseInt(this.selectedRating) 
                                      && d.Speciality == this.specialityValue);
        if(this.doctors.length == 0){
          this.anyData = false;
        }
        else{
          this.anyData = true;
        }
      }

      if (this.isLocate && !this.isSpecial) {
        this.doctors = this.doctors.filter(d => d.Experience >= parseInt(this.selectedExperience) && d.AvgRating >= parseInt(this.selectedRating) 
                                      && d.City == this.locateValue);
        if(this.doctors.length == 0){
          this.anyData = false;
        }
        else{
          this.anyData = true;
        }
      }
      else if (this.isLocate && this.isSpecial) {
        this.doctors = this.doctors.filter(d => d.Experience >= parseInt(this.selectedExperience) && d.AvgRating >= parseInt(this.selectedRating) 
                                      && d.Speciality == this.specialityValue && d.City == this.locateValue);
        if(this.doctors.length == 0){
          this.anyData = false;
        }
        else{
          this.anyData = true;
        }
      }
    });
  }

  expChange() {
    this.isExperience = true;
    this.getDoctors();
    this.doctors = this.filterDoctors
    this.doctors = this.doctors.filter(d => d.Experience >= parseInt(this.selectedExperience) && d.AvgRating >= parseInt(this.selectedRating));
    console.log(this.isSpecial);
  }

  ratChange(){
    this.isRating = true;
    this.getDoctors();
    this.doctors = this.doctors.filter(d => d.Experience >= parseInt(this.selectedExperience) && d.AvgRating >= parseInt(this.selectedRating));
    console.log(this.isSpecial);
  }

  selectChange(){
    this.isSpecial = true;
    this.getDoctors();
    this.doctors = this.doctors.filter(d => d.Experience >= parseInt(this.selectedExperience) && d.AvgRating >= parseInt(this.selectedRating) 
                                      && d.Speciality == this.specialityValue);
  }

  locateChange(){
    this.isLocate = true;
    this.getDoctors();
    this.doctors = this.doctors.filter(d => d.Experience >= parseInt(this.selectedExperience) && d.AvgRating >= parseInt(this.selectedRating) 
                                      && d.Speciality == this.specialityValue && d.City == this.locateValue);
  }
  
  reset(){
    this.selectedExperience = 0;
    this.selectedRating = 0;
    this.SpecialityFormControl.reset();
    this.LocationFormControl.reset();
    this.isLocate = false;
    this.isRating = false;
    this.isExperience = false;
    this.isSpecial = false;
    this.anyData = true;
    this.getDoctors();
  }

}
