import { Injectable } from '@angular/core';
import { Http, RequestOptionsArgs, RequestOptions } from "@angular/http";
import { Observable } from "rxjs/Observable";
import { Router } from '@angular/router';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import { environment } from '../../environments/environment';

@Injectable()
export class doctoravailability
{
    private headers: any;     
    private Url = environment.apiUrl + "/api/DoctorAvailability?email=";
constructor(private http:Http,private routevariable:Router){ }
postdoctimes(details: number[])
{
    var email = localStorage.getItem('username');
    this.headers = new Headers({'Content-Type': 'application/json'});
  return this.http.post( this.Url + email, details, {headers: this.headers})
    .map(res => res.json());  
}
}