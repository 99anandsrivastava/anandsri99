import { Component, OnInit } from '@angular/core';
import { FormControl,FormGroup } from "@angular/forms";
import { Router } from '@angular/router';
import { doctoravailability } from "./doctor-avaibility.service";

@Component({
  selector: 'app-doctor-avaibility',
  templateUrl: './doctor-avaibility.component.html',
  styleUrls: ['./doctor-avaibility.component.css']
})
export class DoctorAvaibilityComponent implements OnInit {
  foods:any;
  slots = [];
  formControls:any = [];


  // time = [{value:0, text:'12.00 AM - 12.30 AM'}, {value:1, text: '12.30 AM - 1.00 AM'},{value:2, text:'1.00 AM - 1.30 AM'},
  // {value:3, text:'1.30 AM - 2.00 AM'},{value:0, text:'2.00 AM - 2.30 AM'},{value:0, text:'2.30 AM - 3.00 AM'},{value:0, text:'3.00 AM - 3.30 AM'},{value:0, text:'3.30 AM - 4.00 AM'},{value:0, text:'4.00 AM - 4.30 AM'},{value:0, text:'4.30 AM - 5.00 AM'},{value:0, text:'5.00 AM - 5.30 AM'},{value:0, text:'5.30 AM - 6.00 AM'},{value:0, text:'6.00 AM - 6.30 AM'},{value:0, text:'6.30 AM - 7.00 AM'},{value:0, text:'7.00 AM - 7.30 AM'},{value:0, text:'7.30 AM - 8.00 AM'},{value:0, text:'8.00 AM - 8.30 AM'},{value:0, text:'8.30 AM - 9.00 AM'},{value:0, text:'9.00 AM - 9.30 AM'},{value:0, text:'9.30 AM - 10.00 AM'},{value:0, text:'10.00 AM - 10.30 AM'},{value:0, text:'10.30 AM - 11.00 AM'},{value:0, text:'11.00 AM - 11.30 AM'},{value:0, text:'11.30 AM - 12.00 PM'},{value:0, text:'12.00 PM - 12.30 PM'},{value:0, text:'12.30 PM - 1.00 PM'},{value:0, text:'1.00 PM - 1.30 PM'},{value:0, text:'1.30 PM - 2.00 PM'}];
// time=[{value:'8.00am-8.30am'},{value:'8.30am-9.00am'},{value:'9.00am-9.30am'},
// {value:'9.30am-10.00am'},{value:'12.00am-12.30pm'},{value:'1.00pm-1.30pm'},{value:'6.00pm-6.30pm'}
// ];
details: number[] = [];
doctime() { 
  for(let i = 0; i< 21; i++) {
    this.details.push(this.formControls[i].value);
  
  }
  this.service.postdoctimes(this.details).subscribe(
    data => {
       this.router.navigate(['/doctor']);
    },
    error=>{
      console.log(error);
    }
  );
}
ngOnChanges() { }
constructor(private service: doctoravailability, private router:Router){
  var d1 = new Date("July 21, 1983 00:00:00");
  this.slots.push({value: -1, text: 'No Slot Required'});
   for(let i = 0; i < 48; i++) {
       var d2 = new Date(d1);
        d2.setMinutes(d1.getMinutes() + 30);
    this.slots.push({value: i, text: d1.toLocaleTimeString() + ' - ' + d2.toLocaleTimeString()});
    d1.setMinutes(d1.getMinutes() + 30);
  }
for(let i = 0; i< 21; i++) {
  this.formControls.push(new FormControl());
}
//  }
// doctime(){
//   this.service.postdoctimes(this.formControls[0].value,this.formControls[1].value,this.formControls[2].value,this.formControls[3].value,
//   this.formControls[4].value,this.formControls[5].value,this.formControls[6].value,this.formControls[7].value,this.formControls[8].value,this.formControls[9].value,
//   this.formControls[10].value,this.formControls[11].value,this.formControls[12].value,this.formControls[13].value,
//   this.formControls[14].value,this.formControls[15].value,this.formControls[16].value,
//   this.formControls[17].value,this.formControls[18].value,this.formControls[19].value,
// this.formControls[20].value).subscribe(response=>{
//   console.log(response.json());
//   if(response.json()==1)
//     {
//       this.router.navigate(['/doctor']);
//     }
//     else if(response.json()==0)
//       {
//         this.router.navigate(['/availability']);
//       }
// })
 }
/*showSelected() {
  alert(this.formControls.value);
}*/
 ngOnInit(){
   
 /* for(let i: 0; i< 21;i++) {
    this.formControls.push(new FormControl());
  }

  this.formControls[0].value*/
   /* this.foods = [
      {value: 'none', viewValue: '10.00am-10.30am'},
    {value: '8.00am-8.30am', viewValue: '8.00am-8.30am'},
    {value: '9.00am-9.30am', viewValue: '9.00am-9.30am'},
    {value: '10.00am-10.30am', viewValue: '10.00am-10.30am'},
    {value: '1.00pm-1.30pm', viewValue: '1.00pm-1.30pm'},
    {value: '2.00pm-2.30pm', viewValue: '10.00am-10.30am'},
    {value: '4.00pm-4.30pm', viewValue: '10.00am-10.30am'},
    {value: '5.00pm-5.30pm', viewValue: '10.00am-10.30am'},
    {value: '6.00pm-6.30pm', viewValue: '10.00am-10.30am'},
    {value: '7.00pm-7.30pm', viewValue: '7.00am-10.30am'}
    ];*/
  
 }
}