import { TestBed, inject } from '@angular/core/testing';

import { DoctorBookingService } from './doctor-booking.service';

describe('DoctorBookingService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DoctorBookingService]
    });
  });

  it('should be created', inject([DoctorBookingService], (service: DoctorBookingService) => {
    expect(service).toBeTruthy();
  }));
});
