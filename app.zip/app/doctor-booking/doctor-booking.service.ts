import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { Observable } from "rxjs/Observable";
import { Http } from "@angular/http";

@Injectable()
export class DoctorBookingService {

  constructor(private http: Http) {
  }


  GetBookingShifts(url) {
    return this.http.get(url).map((res) => res.json());
  }

  SetBookingShifts(url) {
    return this.http.post(url,null).map((res) => res.json());
  }

}
