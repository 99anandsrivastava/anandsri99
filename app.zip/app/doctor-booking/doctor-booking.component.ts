import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { environment } from '../../environments/environment';
import { Observable } from 'rxjs/Observable';
import { Http } from '@angular/http';
import { DoctorBookingService } from './doctor-booking.service';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
@Component({
  selector: 'app-doctor-booking',
  templateUrl: './doctor-booking.component.html',
  styleUrls: ['./doctor-booking.component.css']
})
export class DoctorBookingComponent implements OnInit {

  // private GetAppointmentBaseURL = environment.apiUrl + "/api/Patients/?email=";

  private GetBookingBaseURL = environment.apiUrl + '/api/DocAppoint?';
  private setBookingBaseURL = environment.apiUrl + '/api/DocAppoint?';

  doctorId: any;

  date: any;

  data: any;

  shifts: any;

  patientId: any;

  bookingUrl: string;

              


  constructor(private doctorBookingService: DoctorBookingService,
  
  public toastr: ToastsManager,
              public vcr: ViewContainerRef) {
    this.toastr.setRootViewContainerRef(vcr);
   }
   
  

  ngOnInit() {

    this.doctorId = localStorage.getItem('doctorEmail');
    //localStorage.removeItem('doctorEmail');

    this.date = new Date().toLocaleDateString() + ' '  + new Date().toLocaleTimeString();

    this.patientId = localStorage.getItem('username');

    this.GetBookingBaseURL = this.GetBookingBaseURL + 'doctorId='+this.doctorId+'&date='+this.date;
    console.log(this.GetBookingBaseURL);
    this.GetShifts();

  }



  GetShifts() {
    this.doctorBookingService.GetBookingShifts(this.GetBookingBaseURL).subscribe(
      data => {
        console.log(data);
        this.shifts = data.AvailableShifts;
        this.toastr.info('Loaded shifts', 'Information');
      },
      error => {
        this.toastr.error(error, 'Oops!');
      }
    );
    //this.data.data.AvailableShifts;
  }

  bookShift(shiftId) {
   // this.patientId = 'zach@gmail.com';
    //this.setBookingBaseURL = this.setBookingBaseURL + 'patientId=' + this.patientId + '&shiftId=' + shiftId;
    // this.bookingUrl = this.setBookingBaseURL + 'patientId=' + this.patientId + '&shiftId=' + shiftId;
    this.data = this.doctorBookingService.SetBookingShifts(this.setBookingBaseURL + 'patientId=' + this.patientId + '&shiftId=' + shiftId).subscribe(
      data => {
       console.log('Data: ', data);
        if (data.Message === undefined) {
          this.toastr.success('Request Id: ' + data, 'Successful');
        } else {
          this.toastr.warning(data.Message, 'Warning');
        }
      },
      error => {
        this.toastr.error(JSON.parse(error._body).Message, 'Error');
      }
    );
    // console.log(this.data);
    // alert(this.data);
  }
}
