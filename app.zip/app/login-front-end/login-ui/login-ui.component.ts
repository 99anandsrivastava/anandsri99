import { Component, OnInit } from '@angular/core';
import { LoginService } from '../login-service/login.service';
import { IdentityService } from '../login-service/identity.service';
import { Router, ActivatedRoute, Params } from '@angular/router';
import {FormControl, Validators} from '@angular/forms';
const EMAIL_REGEX = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
@Component({
  selector: 'app-login-ui',
  templateUrl: './login-ui.component.html',

  styleUrls: ['./login-ui.component.css']
})
export class LoginUiComponent implements OnInit {
  
  username: string;
  password: string;
  role: string;
  invalidLogin: boolean;
  
  constructor(private auth: IdentityService, private router: Router, private route: ActivatedRoute) { }
  emailFormControl:any;
  PasswordFormControl:any;
  ngOnInit() {
  if(this.auth.isLoggedIn()){
    this.router.navigate(['']);
  }
  this.emailFormControl = new FormControl('', [
    Validators.required,
    Validators.pattern(EMAIL_REGEX)]);
    this.PasswordFormControl = new FormControl('', [Validators.required]);
  }
  afterLogin() {
    let returnUrl;
    if(this.auth.login(this.username,this.password)){
      this.route.queryParams
      .subscribe(params => {
          returnUrl = params['returnUrl'];
          console.log('Return Url: ', returnUrl);
      });
      // console.log('Right before navigate');
      // let returnUrl = this.route.snapshot.queryParamMap.get('returnUrl');
      // this.router.navigate([returnUrl || '/']);
    }else{
      this.invalidLogin = true;

    }

    // this.auth.getRole().subscribe(res => this.role = res);

    // console.log(this.role);
  }
}
