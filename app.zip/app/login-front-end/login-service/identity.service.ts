import { Router } from '@angular/router';
import { Injectable } from '@angular/core';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { JwtHelper } from 'angular2-jwt';
import { tokenNotExpired } from 'angular2-jwt';
import { Headers, Http } from '@angular/http';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs/Observable';
import { environment } from '../../../environments/environment';
import { Compiler } from '@angular/core';

@Injectable()
export class IdentityService {

  constructor(private http: Http, private router: Router,private toastr: ToastsManager, private _compiler: Compiler) {
  }

  private headers = new Headers({'Content-Type': 'application/x-www-form-urlencoded'});

  role: any;
 
  login(username,password) {
    localStorage.clear();
    this._compiler.clearCache();
    let body = "grant_type=password&username=" + username + "&password=" + password;
    this.http.post( environment.apiUrl + '/token', body,{headers: this.headers})
    .map(res => res.json())
    .catch((error: any) => {
        if (error.status == 400) {
          this.toastr.error("Invalid Credentials");
          return Observable.throw(new Error(error.status));
        }
      })
    .subscribe(
      data => {
          localStorage.setItem('id_token', data.access_token);
          localStorage.setItem('username',data.userName);
          this.getRole().subscribe(roleData => {
            this.role = roleData;
            localStorage.setItem('role', this.role);
            if(this.role == 'Patient'){
              this.router.navigate([{ outlets: { primary: 'patient', header: 'header' }}]);
            }
            else if(this.role == 'Doctor'){
              this.router.navigate([{ outlets: { primary: 'doctor', header: 'header' }}]);
            }
            else if(this.role == 'Admin'){
              this.router.navigate([{ outlets: { primary: 'admin', header: 'header' }}]);
            }
          });
        }
      );
      
      // this.getRole().subscribe(roleData => {
      //   this.role = roleData;
      //   console.log(this.role);
      // });

      let token = localStorage.getItem('id_token');
      if(token == null){
        return false;
      }else{
        return true;
      }
  }

  getRole(){
    let name = localStorage.getItem('username');
    console.log('Name: ', name);
    return this.http.get( environment.apiUrl + '/api/account?username='+name)
            .map(res => res.json());
  }

  logout() {
    localStorage.clear();
    this._compiler.clearCache();
    this.router.navigate(['/']);
  }

  isLoggedIn() {
    if(localStorage.getItem('id_token') != null){
      return true;
    }else{
      return false;
    }
  }

  get currentUser(){
    let token = localStorage.getItem('id_token');
    if (!token) return null;
    return new JwtHelper().decodeToken(token); 
  }

}
