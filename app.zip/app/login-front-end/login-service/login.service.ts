import { Injectable } from '@angular/core';
import {Http} from '@angular/http';
import 'rxjs/add/operator/map';

@Injectable()
export class LoginService {

  constructor(private lgin:Http) { 

  }
  public login(uname,pswd){
    return this.lgin.get("http://"+uname+"&pwd="+pswd).map(result =>result.json());
  }
}
