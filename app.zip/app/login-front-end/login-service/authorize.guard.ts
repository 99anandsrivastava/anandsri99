import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { IdentityService } from './identity.service';

@Injectable()
export class AuthorizeGuard implements CanActivate {
role: string;
  constructor(private identityService: IdentityService) { }
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot, ): Observable<boolean> | Promise<boolean> | boolean {
      this.role = localStorage.getItem('role');
      if (this.role.toLowerCase() === next.data['role'][0]) {
          return true;
      } else {
        return false;
      }
  }
}
