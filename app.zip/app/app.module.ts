import { AuthGuard } from './login-front-end/login-service/auth-guard.service';
import { RouterModule, CanActivate } from '@angular/router';
import { HttpModule } from '@angular/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppComponent } from './app.component';
import { DoctorDashboardComponent } from './doctor_dashboard/doctor-dashboard/doctor-dashboard.component';
import { PatientDashboardComponent } from './patient_dashboard/patient-dashboard/patient-dashboard.component';
import { AppointmentPdComponent } from './patient_dashboard/appointment-pd/appointment-pd.component';
import { WeHealUMaterialModule } from './added_modules/material.module';
import { AppointmentDialogComponent } from './doctor_dashboard/appointment-dialog/appointment-dialog.component';
import { PastAppointmentDialogComponent } from './doctor_dashboard/past-appointment-dialog/past-appointment-dialog.component';
import { ReviewDialogComponent } from './doctor_dashboard/review-dialog/review-dialog.component';
import { PendingDialogComponent } from './doctor_dashboard/pending-dialog/pending-dialog.component';
import { ToastModule } from 'ng2-toastr/ng2-toastr';
import { ToastOptions } from 'ng2-toastr';
import { CommonNavbarComponent } from './common/common-navbar/common-navbar.component';
import { WelcomePageComponentComponent } from './welcome_page/welcome-page-component/welcome-page-component.component';
import { UpcomingAppointmentComponent } from './doctor_dashboard/upcoming-appointment/upcoming-appointment.component';
import { CaroselComponent } from './common/carosel/carosel.component';
import { LoginUiComponent } from './login-front-end/login-ui/login-ui.component';
import { LoginService } from './login-front-end/login-service/login.service';
import { AppointmentPdDataComponent } from './patient_dashboard/appointment-pd-data/appointment-pd-data.component';
import { FindDoctorPdComponent } from './patient_dashboard/find-doctor-pd/find-doctor-pd.component';
import { ConsultationPdComponent } from './patient_dashboard/consultation-pd/consultation-pd.component';
import { Routes, RouterLinkActive } from '@angular/router';
import { SignupPatientComponent } from './signup-patient/signup-patient.component';
import { SignupDoctorComponent } from './signup-doctor/signup-doctor.component';
import { SignUpPatientService } from './signup-patient/signup-service';
import { IdentityService } from './login-front-end/login-service/identity.service';
import { GetPatientAppointmentDetails } from './patient_dashboard/patient-dashboard/patient-dashboard.service';
import { SignUpDoctorService } from './signup-doctor/signupDoc-service';
import { DoctorDashboardService } from './doctor_dashboard/doctor-dashboard/doctor-dashboard.service';

import { DoctorSearchService } from './doctor-search/doctor-search.service';
import {DoctorBookingService} from './doctor-booking/doctor-booking.service';
import {AdvertisementComponent} from './welcome_page/Advertisement/advertisement.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { AdminDashBoardService } from './admin-dashboard/admin-dashboard.service';
import { SearchUiComponent } from './doctor-search/search-ui/search-ui.component';
import { SearchProfileComponent } from './doctor-search/search-profile/search-profile.component';
import { PatientDataComponent} from './patient_data/patient_data.component';
import { PatientDataService} from './patient_data/patient_data.service';
import { DoctorDataComponent} from './doctor_data/doctor_data.component';
import { DoctorDataService} from './doctor_data/doctor_data.service';
import { AppointmentDataComponent} from './appointment_data/appointment_data.component';
import { AppointmentDataService} from './appointment_data/appointment_data.service';
import { DoctorProfileComponent } from './doctor-profile/doctor-profile.component';
import { DoctorProfileService } from './doctor-profile/doctor-profile.service';
import { DoctorAvaibilityComponent } from './doctor-avaibility/doctor-avaibility.component';
import { doctoravailability } from './doctor-avaibility/doctor-avaibility.service';
import { AddAdminComponent } from './admin-dashboard/add-admin/add-admin.component';
import { AddAdminService } from './admin-dashboard/add-admin/add-admin-service';
import { AuthorizeGuard } from './login-front-end/login-service/authorize.guard';
import { DoctorBookingComponent } from './doctor-booking/doctor-booking.component';
export class CustomOption extends ToastOptions {
  animate = 'flyLeft'; // you can override any options available
  newestOnTop = true;
  showCloseButton = true;
  dismiss = 'auto';
  toastLife = 5000;
  positionClass = 'toast-bottom-right';
}

@NgModule({
  declarations: [
    AppComponent,
    WelcomePageComponentComponent,
    AdvertisementComponent,
    DoctorDashboardComponent,
    AppComponent,
    DoctorDataComponent,
    PatientDashboardComponent,
    AppointmentPdComponent,
    AppointmentDialogComponent,
    PastAppointmentDialogComponent,
    ReviewDialogComponent,
    PatientDataComponent,
    PendingDialogComponent,
    AppointmentDialogComponent,
    CommonNavbarComponent,
    AppointmentDataComponent,
    UpcomingAppointmentComponent,
    AppointmentPdDataComponent,
    CaroselComponent,
    FindDoctorPdComponent,
    ConsultationPdComponent,
    LoginUiComponent,
    SignupPatientComponent,
    SignupDoctorComponent,
    SearchUiComponent,
    SearchProfileComponent,
    AdminDashboardComponent,
    SignupDoctorComponent,
    DoctorProfileComponent,
    DoctorAvaibilityComponent,
    AddAdminComponent,
    AdminDashboardComponent,
    DoctorBookingComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpModule,
    RouterModule.forRoot([
      {
        path: 'header',
        component: CommonNavbarComponent,
        outlet: 'header'
      },
      {
        path: 'doctor/review',
        component: ReviewDialogComponent,
        data: { role: ['doctor'] },
        canActivate: [AuthGuard, AuthorizeGuard]
      },
      {
        path: 'doctor/profile',
        component: DoctorProfileComponent,
        data: { role: ['doctor'] },
        canActivate: [AuthGuard, AuthorizeGuard]

      },
      {
        path: 'doctor/appointment',
        component: AppointmentDialogComponent,
        data: { role: ['doctor'] },
        canActivate: [AuthGuard, AuthorizeGuard]
      },
      {
        path: 'admin',
        component: AdminDashboardComponent,
        data: { role: ['admin'] },
        canActivate: [AuthGuard, AuthorizeGuard]
      },
      {
        path: 'admin/addadmin',
        component: AddAdminComponent,
        data: { role: ['admin'] },
        canActivate: [AuthGuard, AuthorizeGuard]
      },
      {
        path: 'doctor',
        component: DoctorDashboardComponent,
        data: { role: ['doctor'] },
        canActivate: [AuthGuard, AuthorizeGuard]
      },
      {
        path: 'patient/appointments',
        component: AppointmentPdDataComponent,
        data: { role: ['patient'] },
        canActivate: [AuthGuard, AuthorizeGuard]
      },
      {
        path : 'patient',
        component: PatientDashboardComponent,
        data: { role: ['patient'] },
        canActivate: [AuthGuard, AuthorizeGuard]
      },
      {
        path: 'login',
        component: LoginUiComponent
      },
      {
        path: 'registerPatient',
        component: SignupPatientComponent
      },
      {
        path: 'registerDoctor',
        component: SignupDoctorComponent
      },
      {
        path : 'search',
        component: SearchUiComponent
      },
      {
        path : 'patientData',
        component: PatientDataComponent,
        data: { role: ['admin'] },
        canActivate: [AuthGuard, AuthorizeGuard]
      },

{

  path: 'availability',
  component: DoctorAvaibilityComponent,
   data: { role: ['doctor'] },
        canActivate: [AuthGuard, AuthorizeGuard]
},
{
        path : 'doctorData',
        component: DoctorDataComponent,
        data: { role: ['admin'] },
        canActivate: [AuthGuard, AuthorizeGuard]
      },
      {
        path: 'appointmentData',
        component: AppointmentDataComponent,
        data: { role: ['admin'] },
        canActivate: [AuthGuard, AuthorizeGuard]
      },
      {
        path: 'doctorBooking',
        component: DoctorBookingComponent,
        canActivate: [AuthGuard]
      },
      {
        path: '',
        component: WelcomePageComponentComponent
      }
      ,

      {
        path: '',
        component: CommonNavbarComponent,
        outlet: 'header'
      },

      {
        path: 'home',
        component: WelcomePageComponentComponent
      }
    ]),
    WeHealUMaterialModule,
    ReactiveFormsModule, ToastModule.forRoot()
  ],
  entryComponents: [
    AppointmentDialogComponent,
    PastAppointmentDialogComponent,
    ReviewDialogComponent,
    PendingDialogComponent
  ],
  providers: [{provide: ToastOptions, useClass: CustomOption} ,
                LoginService,
                AuthorizeGuard,
                SignUpPatientService,
                SignUpDoctorService,
                [GetPatientAppointmentDetails],
                DoctorDashboardService,
                IdentityService,
                AuthGuard,
                DoctorDataService,
                DoctorSearchService,
                AdminDashBoardService,
                PatientDataService,
                AppointmentDataService,
                AppointmentDialogComponent,
                DoctorProfileService,
                doctoravailability,
                DoctorBookingService,
                AddAdminService
              ],
  bootstrap: [AppComponent]
})
export class AppModule { }
