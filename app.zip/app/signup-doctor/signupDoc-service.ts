import { Injectable } from '@angular/core';
import { Http, Response, RequestOptions, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import 'rxjs/add/observable/of';
import 'rxjs/add/observable/throw';

import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/filter';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/switchMap';
import { Router } from '@angular/router';
import 'rxjs/add/operator/map';

@Injectable()
export class SignUpDoctorService {

    constructor(private http: Http, private _routeVariable: Router, private toastr: ToastsManager) {
    }

    doctorSpeciality(url: string): Observable<string[]> {
       return this.http.get(url).map(res => res.json());
    }

    ServiceToPostDoc(url: string, param: any){
       
    this.http
        .post(url, param)
        .map(result => 
            {if(result.status == 200) {
                 this.toastr.success("Registartion Successful");
                 this._routeVariable.navigate(['login']);
                 //return 200;
             }}
        )
        .catch((error : any) => {
            if(error.status == 304){
                this.toastr.error("Email Already in use");
                return Observable.throw(new Error(error.status));
            }
        })
        .subscribe();
    
    }   

    private handleError(error: any) {
        let errMsg = (error.message) ? error.message :
            error.status ? `${error.status} - ${error.statusText}` : 'Server error';
        console.error(errMsg);
        return Observable.throw(errMsg);
    }
}