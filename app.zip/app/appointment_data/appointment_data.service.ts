import {Injectable} from '@angular/core';
import { Http} from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/map';
import { environment } from '../../environments/environment';

@Injectable()
export class AppointmentDataService{
 private GetAppointmentDataUrl = environment.apiUrl + "/api/AppointmentData";

 constructor(private _httpclient : Http)
 {

 }

 GetData():Observable<any[]>
    {
        return this._httpclient.get(this.GetAppointmentDataUrl)
        .map(res=>res.json()).do(data => console.log(JSON.stringify(data)));
    }
}