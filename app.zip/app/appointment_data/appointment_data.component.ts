import { Component , OnInit} from '@angular/core';
import{ AppointmentDataService } from './appointment_data.service';
import{ Router } from '@angular/router';
@Component({
    selector: 'app-appointment-data',
    templateUrl: 'appointment_data.component.html'
})

export class AppointmentDataComponent implements OnInit{
appointments: any[];
    constructor( private appointmentService : AppointmentDataService , private rout : Router)
    {

    }

backToDash()
{
    this.rout.navigate(['./admin']);
}
    ngOnInit()
    {
        this.appointmentService.GetData().subscribe
        (appointmentGet => this.appointments = appointmentGet);
    }
}