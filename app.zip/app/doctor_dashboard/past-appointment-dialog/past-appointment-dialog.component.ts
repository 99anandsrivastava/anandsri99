import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-past-appointment-dialog',
  templateUrl: './past-appointment-dialog.component.html',
  styleUrls: ['./past-appointment-dialog.component.css']
})
export class PastAppointmentDialogComponent implements OnInit {

  @Input() history = [];
  
  constructor() { }

  ngOnInit() {
  }

}
