import { Injectable } from '@angular/core';
import { Http } from "@angular/http";
import { Observable } from "rxjs/Observable";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import { environment } from '../../../environments/environment';

import  { Doctor } from '../doctor';

@Injectable()
export class DoctorDashboardService {
  private GetAppointmentBaseUrl= environment.apiUrl +  "/api/Doctors?email=";

  private getPendingUrl = environment.apiUrl + "/api/PendingAppointment";

  constructor(private _httpClient:Http){

  }

   GetDoctorAppointmentDetails(email : any):Observable<any>{
     return this._httpClient.get(this.GetAppointmentBaseUrl  + email)
            .map(res=>res.json());
   }

   getPendingAppointments() {
     return this._httpClient.get(this.getPendingUrl  + "?EmailId=" + localStorage.getItem('username'))
            .map(res => res.json());
   }

   approveAppointment(RequestId) {
     return this._httpClient.put(this.getPendingUrl + "?RequestId=" + RequestId, null);
   }
}
