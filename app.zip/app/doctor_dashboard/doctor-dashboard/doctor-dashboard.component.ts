import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { AppointmentDialogComponent } from '../appointment-dialog/appointment-dialog.component';

import { ReviewDialogComponent } from '../review-dialog/review-dialog.component';
import { PendingDialogComponent } from '../pending-dialog/pending-dialog.component';
import { Observable } from "rxjs/Observable";

import { DoctorDashboardService } from './doctor-dashboard.service';
import { Doctor } from '../doctor';

@Component({
  selector: 'app-doctor-dashboard',
  templateUrl: './doctor-dashboard.component.html',
  styleUrls: ['./doctor-dashboard.component.css']
})
export class DoctorDashboardComponent implements OnInit {

  appResult: any;

  appReviews: any[];

  sum: number = 0;
  average: number = 0;

  countAverage(DocReviews): number {
    for (let review of DocReviews) {
      this.sum = this.sum + review.rating;
    }
    return this.sum / DocReviews.length;
  }

  currentDate = new Date();

  upcoming: any[];
  pending: any[];
  earnings: any = 0;
  doctorName: any;

  nextAppointment: any = "No Appointments Yet";
  pendingCount: any = 0;
  nextPatient: any = "No Appointments Yet";
  bestRating: any = 0;

  //  upcomingCount = this.upcoming.length;

  constructor(private router: Router, private _GetAppointmentDetailsService: DoctorDashboardService) {

  }


  ngOnInit() {
    let user = localStorage.getItem('username');
    this._GetAppointmentDetailsService.getPendingAppointments()
                .subscribe(result => {
                  this.pending = result;
                  if(this.pending){
                  this.pendingCount = this.pending.length;
                  }
                  });
    this._GetAppointmentDetailsService.GetDoctorAppointmentDetails(user)
      .subscribe(doc => {
        this.appResult = doc;
        if (this.appResult.reviews == null) {
          this.average = 0;
        }
        else {
          this.appReviews = this.appResult.reviews.sort((a, b) => {
            return b.rating - a.rating;
          });
          if(this.appReviews[0]){
          this.bestRating = this.appReviews[0].rating;
          this.average = this.countAverage(this.appReviews);
          }
          else{
            this.average = 0;
          }
          
        }
          this.doctorName = this.appResult.name;
          
          if (this.appResult.appointments) {
            this.nextAppointment = this.appResult.appointments.filter(x => x.isApproved &&
              Date.parse((x.shift.startTime)) > Date.parse(this.currentDate.toString())).sort(
              (a, b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime())[0];
          }
          if (this.nextAppointment) {
            this.nextPatient = this.nextAppointment.patientName;
          }
          
          
          this.earnings = this.appResult.appointments.filter(x => x.isApproved &&
            Date.parse(x.shift.startTime) < Date.parse(this.currentDate.toString())).length * this.appResult.price;
        
      });

  }

  openAppointments() {
    this.router.navigate(['doctor/appointment']);
  }

  openReviews() {
    this.router.navigate(['doctor/review']);
  }

  openPending() {

  }

}
