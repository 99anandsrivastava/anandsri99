import { Component, OnInit , Input } from '@angular/core';

@Component({
  selector: 'app-upcoming-appointment',
  templateUrl: './upcoming-appointment.component.html',
  styleUrls: ['./upcoming-appointment.component.css']
})
export class UpcomingAppointmentComponent implements OnInit {

  @Input('docAppointments') upcoming = [];

  constructor() { }

  ngOnInit() {
  }

}
