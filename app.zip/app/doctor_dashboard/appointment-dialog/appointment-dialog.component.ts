import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';

import { DoctorDashboardService} from "../doctor-dashboard/doctor-dashboard.service";
import { PastAppointmentDialogComponent } from '../past-appointment-dialog/past-appointment-dialog.component';
import {Observable} from "rxjs/Observable";
@Component({
  selector: 'app-appointment-dialog',
  templateUrl: './appointment-dialog.component.html',
  styleUrls: ['./appointment-dialog.component.css']
})
export class AppointmentDialogComponent implements OnInit {


  currentDate = new Date();

  appResult : any;


  upcoming : any[];
  pending : any[];
  previous : any[]; 

  options = {
      weekday: "long", year: "numeric", month: "short",  
    day: "numeric", hour: "2-digit", minute: "2-digit" 
  };

  transformDate(appointments) : any[]{
    for(let app of appointments){
      let appDate = new Date(app.startTime);
      app.startTime = appDate.toLocaleDateString("en-us",this.options);
    }
    return appointments;
  }

  constructor(private router : Router, private docService : DoctorDashboardService) { }

  getAppointment(){
    let user = localStorage.getItem('username');
      this.docService.GetDoctorAppointmentDetails(user)
          .subscribe(doc => {
            this.appResult = doc;
            this.appResult.appointments = this.transformDate(this.appResult.appointments);  
            this.upcoming = this.appResult.appointments.filter(x => x.isApproved && 
            Date.parse((x.shift.startTime)) > Date.parse(this.currentDate.toString())).sort(
                          (a,b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime());          
             
            this.pending = this.appResult.appointments.filter(x => x.isApproved == false).
                      sort((a,b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime()); 

            this.previous = this.appResult.appointments.filter(x => x.isApproved && 
            Date.parse((x.shift.startTime)) < Date.parse(this.currentDate.toString())).sort(
                          (a,b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime());          
          });
  }

  ngOnInit() {
    this.getAppointment();
  }

  backToDash(){
    this.router.navigate(['doctor']);
  }
  loadAppointments(){
    this.getAppointment();
  }
}
