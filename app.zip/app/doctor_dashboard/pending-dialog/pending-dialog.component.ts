import { Component, OnInit, Input, EventEmitter } from '@angular/core';

import { DoctorDashboardService } from '../doctor-dashboard/doctor-dashboard.service';

@Component({
  selector: 'app-pending-dialog',
  templateUrl: './pending-dialog.component.html',
  styleUrls: ['./pending-dialog.component.css']
})
export class PendingDialogComponent implements OnInit {

  pending = [];
  

  constructor(private doctorService: DoctorDashboardService) { 
    this.getPending();
  }


  approve(ShiftId){
    this.doctorService.approveAppointment(ShiftId)
        .subscribe(result => this.getPending());
  }

  getPending() { 
    this.doctorService.getPendingAppointments()
        .subscribe(result => this.pending = result);
  }

  ngOnInit() {
    
  }

}
