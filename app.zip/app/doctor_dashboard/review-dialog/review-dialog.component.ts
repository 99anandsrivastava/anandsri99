import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';

import { DoctorDashboardService } from '../doctor-dashboard/doctor-dashboard.service';

@Component({
  selector: 'app-review-dialog',
  templateUrl: './review-dialog.component.html',
  styleUrls: ['./review-dialog.component.css']
})
export class ReviewDialogComponent implements OnInit {

  constructor(private router : Router, private docService : DoctorDashboardService) { }

  appResult : any;

  Reviews : any[];
 

  ngOnInit() {
    let user = localStorage.getItem('username');
    this.docService.GetDoctorAppointmentDetails(user)
          .subscribe(doc => {
            this.appResult = doc;
            this.Reviews = this.appResult.reviews

          });
  }

  backToDash(){
    this.router.navigate(['doctor']);
  }
}
