export class Doctor {
    name : string;
    email : string;
    experience : number;
    picture : string;
    speciality : string;
    rating : number;
    isAuthorized : boolean;
    bio : string;
    shift : any[];
    reviews : any[];
    appointments : any[];
}