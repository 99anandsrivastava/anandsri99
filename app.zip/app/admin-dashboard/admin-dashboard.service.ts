import { Injectable } from '@angular/core';
import { Http } from "@angular/http";
import { Observable } from "rxjs/Observable";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import { environment } from '../../environments/environment';

@Injectable()
export class AdminDashBoardService {
    private GetStatsUrl = environment.apiUrl + "/api/Admin";

    constructor(private _httpClient: Http)
    {

    }

    GetStats():Observable<any> {
        return this._httpClient.get(this.GetStatsUrl)
        .map(res=>res.json());
    }
}