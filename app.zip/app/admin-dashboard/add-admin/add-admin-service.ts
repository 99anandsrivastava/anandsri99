import { Injectable } from '@angular/core';
import { Http } from "@angular/http";
import { Observable } from "rxjs/Observable";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { environment } from '../../../environments/environment';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { Router } from '@angular/router';

@Injectable()
export class AddAdminService {
    private GetStatsUrl = environment.apiUrl + "/api/Admin";

    constructor(private _httpClient: Http, private  _routeVariable: Router, private toastr: ToastsManager)
    {

    }

    addAdminPostRequest(url: string, param: any){
        this._httpClient
            .post(url, param)
            .map(result => 
            {
                if(result.status == 201){
                    this.toastr.success("Admin added successfuly");
                    this._routeVariable.navigate(['admin']);
                }
            })
            .catch((error: any) => {
                if(error.status == 409){
                    this.toastr.error("Admin email exists");
                    return Observable.throw(new Error(error.status));
                }
                else{
                    this.toastr.error("Error in Registering");
                }
            })
            .subscribe();
    }

    private handleError(error: any) {
        let errMsg = (error.message) ? error.message :
            error.status ? `${error.status} - ${error.statusText}` : 'Server error';
        console.error(errMsg);
        return Observable.throw(errMsg);
    }
}