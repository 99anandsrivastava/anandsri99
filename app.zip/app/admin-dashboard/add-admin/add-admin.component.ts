import { Component, OnInit } from '@angular/core';
import {FormControl, Validators} from '@angular/forms';
import { AddAdminService } from './add-admin-service';
import { environment } from '../../../environments/environment'
import { Observable } from 'rxjs/Observable';
const EMAIL_REGEX = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
const PASSWORD_REGEX = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&]{8,}/;

const ONLY_LETTERS = /^[a-zA-Z]$/

@Component({
  selector: 'app-add-admin',
  templateUrl: './add-admin.component.html',
  styleUrls: ['./add-admin.component.css']
})
export class AddAdminComponent implements OnInit {

  constructor(private _addAdminVariable: AddAdminService) { }

  Name: any;
  Email: any;
  Password: any;
  ConfirmPassword: any;
  NameFormControl: any;
  emailFormControl: any;
  PasswordFormControl: any;
  ConfirmPasswordFormControl: any;
  passwordMatch: boolean = true;

  ngOnInit() {
    this.NameFormControl = new FormControl('', [Validators.required, Validators.pattern(ONLY_LETTERS)]);
    this.emailFormControl = new FormControl('', [Validators.required, Validators.pattern(EMAIL_REGEX)]);
    this.PasswordFormControl = new FormControl('', [Validators.required, Validators.pattern(PASSWORD_REGEX)]);
    this.ConfirmPasswordFormControl = new FormControl('', [Validators.required]);
  }

  addAdmin(){
    let password = this.Password;
    let confirmPassword = this.ConfirmPassword;
    if(password != confirmPassword) {
      this.passwordMatch = false;
      return;
    }
    this._addAdminVariable.addAdminPostRequest(environment.apiUrl + '/api/admin', {'Name': this.Name, 'Email': this.Email, 'Password': this.Password})
    this.ConfirmPasswordFormControl.reset();
    this.PasswordFormControl.reset();
    this.emailFormControl.reset();
    this.NameFormControl.reset();
  }

}
