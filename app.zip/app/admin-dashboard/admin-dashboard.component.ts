import { Component, OnInit } from '@angular/core';
import { Observable } from "rxjs/Observable";
import { Router} from '@angular/router';
import { AdminDashBoardService} from './admin-dashboard.service';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit {

  appStats: any;
  patientCount: number;
  doctorCount : number;
  appointmentCount: number ;

  constructor(private _GetStatsService : AdminDashBoardService , private _rout : Router) { }

  redirect()
  {
    this._rout.navigate(['./patientData']);
  }

  redirectDoctor()
  {
    this._rout.navigate(['./doctorData']);
  }

  redirectAppointment()
  {
    this._rout.navigate(['/appointmentData']);
  }

  addAdmin()
  {
    this._rout.navigate(['admin/addadmin']);
  }

  ngOnInit() {
    this._GetStatsService.GetStats().subscribe(data=> {
      this.patientCount = data.PatientsCount;
     this.appointmentCount = data.AppointmentsCount;
     this.doctorCount = data.DoctorsCount;
    },
    error => {
      console.log(error);
    });
    
    
  }
  

}
