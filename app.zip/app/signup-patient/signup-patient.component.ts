import { Component, OnInit, ViewContainerRef } from '@angular/core';
import {FormControl, Validators} from '@angular/forms';
import { SignUpPatientService } from './signup-service';
import { Router } from '@angular/router';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { environment } from '../../environments/environment';

const EMAIL_REGEX = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

const PASSWORD_REGEX = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&]{8,}/;
const AADHAR_REGEX = /^\d{4}\d{4}\d{4}$/;
const ZIP_REGEX = /^[0-9]{6,7}$/;
const ONLY_LETTERS_REGEX = /^[a-zA-Z\s]*$/;
const CITY_AND_STATE_REGEX = /^[a-zA-Z\s]*$/


@Component({
  selector: 'app-signup-patient',
  templateUrl: './signup-patient.component.html',
  styleUrls: ['./signup-patient.component.css']
})
export class SignupPatientComponent implements OnInit {
  startDate = new Date(1990, 0, 1);

  firstName: string;
  lastName: string;
  DOB: any;
  Aadhar: any;
  address1: any;
  address2: any;
  City: string;
  State: string;
  zip: any;
  Email: any;
  Password: any;
  ConfirmPassword: any;
  genders: any;
  address: any;
  gender: any;

  constructor(private _SignUpPatientService: SignUpPatientService,
              private _routeVariable: Router,
              public toastr: ToastsManager,
              public vcr: ViewContainerRef) {
    this.toastr.setRootViewContainerRef(vcr);
   }

  emailFormControl: any;
  FirstNameFormControl: any;
  LastNameFormControl: any;
  DOBFormControl: any;
  AadharFormControl: any;
  AddressLine1FormControl: any;
  CityFormControl: any;
  StateFormControl: any;
  ZipFormControl: any;
  PasswordFormControl: any;
  ConfirmPasswordFormControl: any;
  GenderFormControl: any;
  responseStatus: any;
  code: any;
  passwordMatch: any;

  ngOnInit() {
    this.genders = [
    {value: 'M', viewValue: 'Male'},
    {value: 'F', viewValue: 'Female'},
    {value: 'O', viewValue: 'Other'}
    ];

    this.FirstNameFormControl = new FormControl('', [Validators.required, Validators.pattern(ONLY_LETTERS_REGEX)]);
    this.LastNameFormControl = new FormControl('', [Validators.required, Validators.pattern(ONLY_LETTERS_REGEX)]);
    this.DOBFormControl = new FormControl('', [Validators.required]);

    this.AadharFormControl = new FormControl('',
    [Validators.required, Validators.pattern(AADHAR_REGEX), Validators.minLength(12), Validators.maxLength(12)]);

    this.AddressLine1FormControl = new FormControl('', [Validators.required]);
    this.CityFormControl = new FormControl('', [Validators.required, Validators.pattern(CITY_AND_STATE_REGEX)]);
    this.StateFormControl = new FormControl('', [Validators.required, Validators.pattern(CITY_AND_STATE_REGEX)]);
    this.ZipFormControl = new FormControl('', [Validators.required, Validators.pattern(ZIP_REGEX)]);
    this.GenderFormControl = new FormControl('', [Validators.required]);

    this.emailFormControl = new FormControl('', [Validators.required, Validators.pattern(EMAIL_REGEX)]);

    this.PasswordFormControl = new FormControl('', [Validators.required, Validators.pattern(PASSWORD_REGEX)]);
    this.ConfirmPasswordFormControl = new FormControl('', [Validators.required, Validators.pattern(PASSWORD_REGEX)]);
    this.address = this.address1 + this.address2;
  }

  OnSubmitClick(){
    let password = this.Password;
    let confirmPassword = this.ConfirmPassword;
    if (password != confirmPassword) {
      this.passwordMatch = false;
      return;
    }
    this.code = this._SignUpPatientService.ServiceToPost(environment.apiUrl + '/api/patients',
            {'DOB': this.DOB, 'gender': this.gender, 'returnCustomer': 0,
            'aadhar': this.Aadhar, 'address1': this.address1, 'address2': this.address2,
            'city': this.City, 'state': this.State, 'zip': this.zip, 'Email': this.Email,
            'PasswordHash': this.Password, 'firstName': this.firstName, 'lastName': this.lastName});
    this.code = this._SignUpPatientService.ServiceToPost(environment.apiUrl + '/api/patients',
    {'DOB': this.DOB, 'gender': this.gender, 'returnCustomer': 0,
    'aadhar': this.Aadhar, 'address1': this.address1, 'address2': this.address2,
    'city': this.City, 'state': this.State, 'zip': this.zip, 'Email': this.Email,
    'PasswordHash': this.Password, 'firstName': this.firstName, 'lastName': this.lastName});
  }

  onErrorGoTo() {
    this.toastr.error('This Email ID is already registered!', 'Oops!');
  }
}
