import { Injectable, ViewContainerRef } from '@angular/core';
import { Http, Response, Headers, RequestOptions, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Observable';

import 'rxjs/add/observable/of';
import 'rxjs/add/observable/throw';

import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/filter';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/switchMap';
import { Router } from "@angular/router";
import { ToastsManager } from "ng2-toastr/ng2-toastr";
import { SignupPatientComponent } from "./signup-patient.component";
import { Subject } from "rxjs/Subject";
import { timeout } from "rxjs/operator/timeout";

@Injectable()
export class SignUpPatientService {

    constructor(private http: Http, private _routeVariable : Router, private toastr: ToastsManager) {}
    _SignUpPatientComponent : SignupPatientComponent


    ServiceToPost(url: string, param: any) {
    this.http
        .post(url, param)
        .map(result => 
            {
             if(result.status == 200) {
                 console.log("200");
                 this.toastr.success("Registration Successful");
                 this._routeVariable.navigate(['login']);
                 //return 200;
             }}
        )
        .catch((error : any) => {
            if(error.status == 304){
                this.toastr.error("Email Already in use");
                return Observable.throw(new Error(error.status));
            }
        })
        .subscribe();
    }   

    private handleError(error: any) {
        let errMsg = (error.message) ? error.message :
            error.status ? `${error.status} - ${error.statusText}` : 'Server error';
        console.error(errMsg);
        return Observable.throw(errMsg);
    }
}